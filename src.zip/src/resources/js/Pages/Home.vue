<template>
        <Head>
            <title>
                Website Scanner - Home
            </title>
        </Head>
        <h1 class="text-3xl tracking-wide text-gray-800">HOME</h1>
</template>
